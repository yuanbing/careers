# Create your views here.
from blogs.models import Blog
from blogs.models import Comment
from django.http import HttpResponseRedirect, HttpResponse
from django.template import Context, loader
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.core.urlresolvers import reverse
import datetime

def index(request):
    latest_blogs = Blog.objects.all().order_by('-pub_date')[:20]
    t = loader.get_template('index.html')
    c = Context({
        'latest_blogs': latest_blogs, 
    })
    return HttpResponse(t.render(c))
    
def blogdetail(request, blog_id):
    blog_entry = get_object_or_404(Blog, pk=blog_id)
    return render_to_response('detail.html', {'blog_entry': blog_entry}, context_instance=RequestContext(request))
    
def addcomment(request, blog_id):
    blog_entry = get_object_or_404(Blog, pk=blog_id)
    new_blog_comment = request.POST['comment_content']
    if new_blog_comment:
        new_comment_entry = Comment.objects.create(blog_id=blog_entry.id, pub_date=datetime.date.today())
        #new_comment_entry.blog.id = blog_entry.id
        new_comment_entry.content = new_blog_comment
        #new_comment_entry.pub_date = datetime.date.today()
        new_comment_entry.save()
        blog_entry.save()
        return HttpResponseRedirect(reverse('blogs.views.blogdetail', args=(blog_entry.id,)))
    else: 
        return render_to_response('detail.html', {'blog_entry': blog_entry}, context_instance=RequestContext(request))
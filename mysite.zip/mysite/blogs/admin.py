from blogs.models import Blog
from django.contrib import admin

class BlogAdmin(admin.ModelAdmin):
    field_sets = [
        (None), {'fields': ['title', 'pub_date']}
    ]
    
    list_display = ('slug', 'pub_date')
    
admin.site.register(Blog, BlogAdmin)